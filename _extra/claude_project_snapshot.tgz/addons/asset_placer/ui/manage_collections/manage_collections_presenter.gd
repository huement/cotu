class_name ManageCollectionsPresenter
extends RefCounted

signal assets_changed(assets: Array[AssetResource])
signal selection_changed(indices: PackedInt32Array, batch_mode: bool)
signal collections_changed(collections: Array[CollectionState], batch_mode: bool)

enum SelectMode { SINGLE, RANGE, MULTI }


class CollectionState:
	var collection: AssetCollection
	var assigned_count: int = 0
	var total_selected: int = 0
	var is_primary: bool = false

	func is_full() -> bool:
		return assigned_count == total_selected and total_selected > 0

	func is_partial() -> bool:
		return assigned_count > 0 and assigned_count < total_selected

	func is_available() -> bool:
		return assigned_count < total_selected or total_selected == 0


var _asset_library: AssetLibrary:
	get:
		return AssetLibraryManager.get_asset_library()

var _assets: Array[AssetResource] = []
var _selected_indices: PackedInt32Array = []
var _batch_mode: bool = false
var _last_toggled_index: int = -1


func ready(initial_asset_id: String = ""):
	_assets = _asset_library.get_assets()
	if not initial_asset_id.is_empty():
		for i in _assets.size():
			if _assets[i].id == initial_asset_id:
				_selected_indices = PackedInt32Array([i])
				_last_toggled_index = i
				break
	elif not _assets.is_empty():
		_selected_indices = PackedInt32Array([0])
		_last_toggled_index = 0
	_emit_assets()
	_emit_selection()
	_emit_collections()


func toggle_asset(index: int, mode: SelectMode):
	if index < 0 or index >= _assets.size():
		return

	match mode:
		SelectMode.RANGE:
			if _last_toggled_index >= 0:
				_select_range(_last_toggled_index, index)
			else:
				_selected_indices = PackedInt32Array([index])
				_last_toggled_index = index
				_emit_selection()
				_emit_collections()

		SelectMode.MULTI:
			_batch_mode = true
			var pos := _index_in_selection(index)
			if pos >= 0:
				_selected_indices.remove_at(pos)
			else:
				_selected_indices.push_back(index)
			_last_toggled_index = index
			_emit_selection()
			_emit_collections()

		SelectMode.SINGLE:
			_batch_mode = false
			_selected_indices = PackedInt32Array([index])
			_last_toggled_index = index
			_emit_selection()
			_emit_collections()


func select_all():
	if not _batch_mode:
		_batch_mode = true

	_selected_indices.clear()
	for i in _assets.size():
		_selected_indices.push_back(i)

	_emit_selection()
	_emit_collections()


func filter_assets(query: String):
	var all_assets := _asset_library.get_assets()

	if query.is_empty():
		_assets = all_assets
	else:
		_assets = all_assets.filter(func(asset: AssetResource): return asset.name.containsn(query))

	_selected_indices.clear()
	if not _assets.is_empty():
		_selected_indices = PackedInt32Array([0])
		_last_toggled_index = 0

	_emit_assets()
	_emit_selection()
	_emit_collections()


func set_primary_collection(collection: AssetCollection):
	for idx in _selected_indices:
		var asset := _assets[idx]
		if asset.primary_collection == collection.id:
			asset.primary_collection = -1
		else:
			asset.primary_collection = collection.id
		_asset_library.update_asset(asset)
	_emit_collections()


func add_to_collection(collection: AssetCollection):
	for idx in _selected_indices:
		var asset := _assets[idx]
		if not asset.tags.has(collection.id):
			asset.add_tag(collection.id)
			_asset_library.update_asset(asset)
	_emit_collections()


func remove_from_collection(collection: AssetCollection):
	for idx in _selected_indices:
		var asset := _assets[idx]
		asset.remove_tag(collection.id)
		if asset.primary_collection == collection.id:
			asset.primary_collection = -1
		_asset_library.update_asset(asset)
	_emit_collections()


func _select_range(from_index: int, to_index: int):
	if not _batch_mode:
		_batch_mode = true

	var start_idx := mini(from_index, to_index)
	var end_idx := maxi(from_index, to_index)

	for i in range(start_idx, end_idx + 1):
		if _index_in_selection(i) < 0:
			_selected_indices.push_back(i)

	_last_toggled_index = to_index
	_emit_selection()
	_emit_collections()


func _index_in_selection(index: int) -> int:
	for i in _selected_indices.size():
		if _selected_indices[i] == index:
			return i
	return -1


func _emit_assets():
	assets_changed.emit(_assets)


func _emit_selection():
	selection_changed.emit(_selected_indices, _batch_mode)


func _emit_collections():
	var collections: Array[CollectionState] = []
	var all_collections := _asset_library.get_collections()
	var total := _selected_indices.size()

	var collection_counts: Dictionary = {}
	for idx in _selected_indices:
		for tag in _assets[idx].tags:
			collection_counts[tag] = collection_counts.get(tag, 0) + 1

	var primary_id: int = -1
	if total == 1:
		primary_id = _assets[_selected_indices[0]].get_primary_collection()

	for collection in all_collections:
		var cs := CollectionState.new()
		cs.collection = collection
		cs.assigned_count = collection_counts.get(collection.id, 0)
		cs.total_selected = total
		cs.is_primary = collection.id == primary_id
		collections.push_back(cs)

	collections.sort_custom(
		func(a: CollectionState, b: CollectionState):
			var a_full := a.is_full()
			var b_full := b.is_full()
			if a_full != b_full:
				return a_full

			var a_partial := a.is_partial()
			var b_partial := b.is_partial()
			if a_partial != b_partial:
				return a_partial

			return false
	)

	collections_changed.emit(collections, _batch_mode)
