class_name AssetParentSelector
extends RefCounted


static func pick_parent(root: Node3D, asset: AssetResource, auto_group: bool) -> Node3D:
	var primary_id := asset.get_primary_collection()
	if not auto_group or primary_id < 0:
		return root

	var lib := AssetLibraryManager.get_asset_library()
	var collection = lib.get_collection(primary_id)
	var expected_name = collection.name.capitalize()
	var existing_chidren = root.find_children(expected_name, "Node3D", true)
	var group_parent: Node3D
	if existing_chidren.is_empty():
		group_parent = Node3D.new()
		print("Not found with name %s" % expected_name)
		group_parent.name = expected_name
		root.add_child(group_parent)
		group_parent.owner = EditorInterface.get_edited_scene_root()

	else:
		group_parent = existing_chidren[0]

	return group_parent
