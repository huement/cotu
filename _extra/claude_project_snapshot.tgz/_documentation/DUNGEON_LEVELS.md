# Dungeon Levels

Dungeons are built from room **parts** (hand-made scenes) joined by Kenney corridor tiles. They aren't painted on a GridMap like the caves.

## Files

| File | What it does |
|---|---|
| `Scenes/Dungeons/Parts/SmallRoom, WideRoom, LargeRoom, CornerRoom.tscn` | Room parts. Each has the `DungeonRoom.gd` script. |
| `Scenes/Dungeons/Parts/BossChamber.tscn` | The boss room, hand-built with the boss GridMaps. It has a single doorway (S); Cap_N stays shut, and Cap_W/Cap_E are side chambers that open after the boss fight (LATER). |
| `Scripts/Dungeon/DungeonRoom.gd` | At load time it removes the caps on connected doorways and the rolled-out dressing, then prefixes every `object_id` in the room. |
| `Scripts/Dungeon/DungeonLevel.gd` | Root of a generated level. Holds `map_type`, `bgm_track_name` and the seed it was built with. |
| `Scripts/Dungeon/DungeonGenerator.gd` | Layout logic: reads the room templates, places rooms and corridors, builds the movement model and picks enemy spots. |
| `Scripts/Utilities/GenerateDungeonLevel.gd` | EditorScript that builds a level and saves it as a `.tscn`. |
| `resources/mesh_library/nav_blocker_mesh_library.tres` | Invisible "nav-blocker" tile used on WallMap to mark corridor walls. |
| `Scenes/Dungeons/DungeonLevel1.tscn` | The first dungeon. Its entrance is the RockCave in GloomReach. |

## Making a new level

1. Open `Scripts/Utilities/GenerateDungeonLevel.gd` and edit the CONFIGURATION block: `LEVEL_NAME`, `LEVEL_SEED`, `ROOM_COUNT`, `ENEMY_COUNT`, `ENEMY_DATA`, the room weights, and where the entrance stairs lead back to.
2. Run it with **File → Run**. The level is saved and opened.
3. If you don't like the layout, change `LEVEL_SEED` and run it again. Running with the same name overwrites the file.
4. Hook the level up: point a CryptHole, StoneGate or Stairs at it (`target_dungeon_scene` / `target_scene`, plus `arrival_point_name`).

## How a level is put together

- **Grid.**
  - The world is laid out in 4 m modules; module (i, j) is centred at world (4i+3, 4j+3), which is always a 2 m movement-cell centre.
  - Rooms sit on a module centre, rotated 0/90/180/270.
- **Entrance and growth.**
  - The level starts from a dead-end corridor at module (0, 0). Its stairs lead back up, and the party spawns one cell east, facing east.
  - The generator then grows from open doorways: a corridor 0–3 modules long (sometimes with a turn), then a weighted random room rotated so that one of its doorways meets the corridor.
  - Doorways that are never used keep their gate (`Cap_X`).
- **Boss chamber.** Attached last, off the deepest open doorway.
- **Collision.**
  - Rooms block with their own `Walls`/`Caps` collision.
  - Corridors are bare models. Their walls are blocked by invisible tiles on `WallMap`, which MapManager treats as walls.
- **Checking and enemies.**
  - The generator floods the walkable cells with the same 1.6 m box test the player uses, so it can check that everything is reachable.
  - Enemies go on reachable room cells (never in the boss room): at most 2 per room, away from doorways and the entrance. A spot is rejected if an enemy standing there would cut anything off.
- **Save state.**
  - Each placed room gets an `id_prefix` (e.g. `dungeonlevel1_room3_largeroom`), so chests and masks keep their own save state.
  - `object_id`s must be globally unique, because save state is keyed by the scene name "World".

## Rules for room parts (so the generator can read them)

- **Doors.** `Doors/Door_N|E|S|W` are Marker3Ds on the doorway cell, with −Z pointing OUT of the room. The letters are room-local: N = −Z, E = +X.
- **Walls.** `Walls` is a StaticBody3D with one BoxShape3D per blocked cell. The room's size is worked out from these boxes (or from the GridMap tiles, for the boss chamber).
- **Caps.** `Caps/Cap_X` is a gate plus a box blocker for each doorway.
- **Dressing.**
  - Dressing is any node with **Unique Name (%)** outside RoomModel/Walls/Doors/Caps.
  - Plain Node3D folders are searched, not removed.
  - Torches use `torch_chance`; everything else uses `decor_chance`. Per-node metadata `spawn_chance` overrides both.
- **Blocking props.** Barrel, Column, Bones, Stones, chest and HypeChest block their cell. They are counted in the reachability check.

## Not done yet

- Boss enemy, and the boss-defeat logic that lowers Cap_W/Cap_E.
- HornedSkull interaction.
- A way out or down from the boss room to a next level.
