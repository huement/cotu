# res://Scripts/Enemies/enemy.gd
class_name WorldEnemy
extends Node3D

## Manages 3D dungeon overworld representation, grid alignment, and multi-enemy combat initiation.

# ==============================================================================
# 1. EXPORTED CONFIGURATION
# ==============================================================================
## Primary enemy resource template
@export var data: Resource

## Explicit list of enemies in this encounter. If populated, overrides 'pack_size'.
@export var enemy_group: Array[Resource] = []

## Number of enemies to spawn when building a pack from 'data'
@export_range(1, 6) var pack_size: int = 2

## Target GridMap cell for initial positioning (Leave at Vector2i.ZERO to auto-detect from 3D Editor placement)
@export var initial_cell: Vector2i = Vector2i.ZERO

## Overworld scale multiplier for the lead enemy model
@export var model_scale: Vector3 = Vector3(0.6, 0.6, 0.6)

## Vertical Y-offset down from cell center (-0.5 grounds feet onto cell floor)
@export var vertical_offset: float = -0.5

@export var enemy_data: EnemyData

@export var enemy_type: String = ""

@export var hasSpottedPlayer: bool = false

# ==============================================================================
# 2. NODE REFERENCES & STATE
# ==============================================================================
@onready var model_holder: Node3D = $ModelHolder as Node3D
@onready var activation_area: Area3D = $ActivationArea as Area3D

const ANIM_MAPPINGS: Dictionary = {
	&"idle": [&"Idle", &"idle", &"IDLE", &"idle_loop", &"Idle_Loop"],
	&"walk": [&"Walk", &"walk", &"WALK", &"walking", &"Walking", &"walk_loop", &"Walk_Loop", &"Run", &"run"]
}

const PATROL_OFFSETS: Array[Vector2i] = [
	Vector2i(0, -1), # North
	Vector2i(1, 0),  # East
	Vector2i(0, 1),  # South
	Vector2i(-1, 0)  # West
]

var _grid_position: Vector2i = Vector2i.ZERO
var _is_in_active_combat: bool = false
var _move_timer: float = 0.0
var _ai: EnemyAI = EnemyAI.new()
var _is_moving: bool = false
var _is_initialized: bool = false
var _saved_editor_pos: Vector3 = Vector3.ZERO
var _patrol_index: int = 0
var _current_facing: Facing = Facing.SOUTH


# Cardinal direction state tracking for retro grid exploration.
enum Facing {
	NORTH,
	EAST,
	SOUTH,
	WEST,
}

# ==============================================================================
# 3. LIFECYCLE & SETUP
# ==============================================================================
func _ready() -> void:
	add_to_group(&"world_enemies")
	_saved_editor_pos = global_position
	
	_resolve_enemy_data()
	_setup_enemy_group()
	_instantiate_world_model()
	_connect_trigger_signals()
	
	call_deferred("_initialize_enemy")


func _initialize_enemy() -> void:
	_align_to_grid()
	if is_instance_valid(model_holder):
		model_holder.rotation_degrees.y = _facing_to_angle(_current_facing)
	_is_initialized = true


func get_grid_pos() -> Vector2i:
	return _grid_position


func _cell_to_world(cell: Vector2i) -> Vector3:
	var map_mgr: Node3D = get_tree().current_scene.find_child("MapManager", true, false) as Node3D
	if not is_instance_valid(map_mgr):
		map_mgr = get_tree().root.find_child("MapManager", true, false) as Node3D

	if is_instance_valid(map_mgr) and map_mgr.has_method("nav_cell_to_world") and is_instance_valid(map_mgr.get_nav_grid()):
		var global_pos: Vector3 = map_mgr.nav_cell_to_world(Vector3i(cell.x, 0, cell.y))
		return Vector3(global_pos.x, global_pos.y + vertical_offset, global_pos.z)
	
	return Vector3(cell.x * 2.0 + 1.0, vertical_offset, cell.y * 2.0 + 1.0)


func _resolve_enemy_data() -> void:
	if enemy_data == null and data is EnemyData:
		enemy_data = data as EnemyData
	elif data == null and enemy_data != null:
		data = enemy_data
	elif data == null and not enemy_group.is_empty() and enemy_group[0] is EnemyData:
		data = enemy_group[0]
		enemy_data = enemy_group[0] as EnemyData

	# If enemy_type is left empty in the Godot Inspector, pull from compiled CSV resource
	if enemy_type.is_empty() and is_instance_valid(enemy_data) and "enemy_type" in enemy_data:
		enemy_type = enemy_data.enemy_type


func _setup_enemy_group() -> void:
	var template: Resource = data
	if not is_instance_valid(template):
		template = enemy_data
	if not is_instance_valid(template) and not enemy_group.is_empty():
		template = enemy_group[0]

	if not is_instance_valid(template):
		if ResourceLoader.exists("res://Data/Enemies/EnZombieCat.tres"):
			template = load("res://Data/Enemies/EnZombieCat.tres") as Resource
		else:
			template = load("res://Data/Enemies/ZombieCat_Base.tres") as Resource
		data = template
		enemy_data = template as EnemyData

	if enemy_group.size() < pack_size or (enemy_group.size() == 1 and pack_size > 1):
		enemy_group.clear()
		for i: int in range(pack_size):
			if is_instance_valid(template):
				var dup: Resource = template.duplicate(true)
				
				if "resource_path" in template and not template.resource_path.is_empty():
					dup.resource_path = template.resource_path
				if "model_scene" in template and template.get("model_scene") != null:
					dup.set("model_scene", template.get("model_scene"))
				if "custom_material" in template and template.get("custom_material") != null:
					dup.set("custom_material", template.get("custom_material"))
				if "texture_path" in template and not str(template.get("texture_path")).is_empty():
					dup.set("texture_path", template.get("texture_path"))
				
				enemy_group.append(dup)


func _align_to_grid() -> void:
	var map_mgr: Node3D = get_tree().current_scene.find_child("MapManager", true, false) as Node3D
	if not is_instance_valid(map_mgr):
		map_mgr = get_tree().root.find_child("MapManager", true, false) as Node3D

	var grid: GridMap = null
	if is_instance_valid(map_mgr) and map_mgr.has_method("get_nav_grid"):
		grid = map_mgr.get_nav_grid()

	if initial_cell != Vector2i.ZERO:
		_grid_position = initial_cell
	elif is_instance_valid(grid):
		var local_pos: Vector3 = grid.to_local(_saved_editor_pos)
		var map_cell: Vector3i = grid.local_to_map(local_pos)
		_grid_position = Vector2i(map_cell.x, map_cell.z)
		initial_cell = _grid_position
	elif is_instance_valid(map_mgr) and map_mgr.has_method("world_to_grid"):
		var map_cell: Vector3i = map_mgr.world_to_grid(_saved_editor_pos)
		_grid_position = Vector2i(map_cell.x, map_cell.z)
		initial_cell = _grid_position
	else:
		_grid_position = Vector2i(roundi((_saved_editor_pos.x - 1.0) / 2.0), roundi((_saved_editor_pos.z - 1.0) / 2.0))
		initial_cell = _grid_position

	global_position = _cell_to_world(_grid_position)


func _instantiate_world_model() -> void:
	if not is_instance_valid(model_holder):
		return

	var lead_resource: Resource = data
	if not is_instance_valid(lead_resource) and not enemy_group.is_empty() and is_instance_valid(enemy_group[0]):
		lead_resource = enemy_group[0]

	var model_scene: PackedScene = null
	if is_instance_valid(lead_resource) and "model_scene" in lead_resource:
		model_scene = lead_resource.get("model_scene") as PackedScene

	if is_instance_valid(model_scene):
		var model_inst: Node3D = model_scene.instantiate() as Node3D
		model_inst.scale = model_scale
		_apply_material_to_model(model_inst, lead_resource)
		model_holder.add_child(model_inst)
		_play_animation(&"idle", true)
	else:
		var mesh_inst := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(0.6, 1.2, 0.6)
		mesh_inst.mesh = box

		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color.RED
		mesh_inst.material_override = mat
		model_holder.add_child(mesh_inst)


func _apply_material_to_model(model_node: Node3D, e_data: Resource) -> void:
	if not is_instance_valid(model_node) or not is_instance_valid(e_data):
		return

	var mat: Material = null

	if "custom_material" in e_data and is_instance_valid(e_data.get("custom_material")):
		mat = e_data.get("custom_material") as Material

	if mat == null and "texture_path" in e_data and not str(e_data.get("texture_path")).is_empty():
		var tex_path: String = str(e_data.get("texture_path"))
		if ResourceLoader.exists(tex_path):
			var tex: Texture2D = load(tex_path) as Texture2D
			if is_instance_valid(tex):
				var std_mat := StandardMaterial3D.new()
				std_mat.albedo_texture = tex
				std_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
				std_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
				mat = std_mat

	if is_instance_valid(mat):
		_apply_material_override_recursive(model_node, mat)


func _apply_material_override_recursive(node: Node, mat: Material) -> void:
	if node is MeshInstance3D:
		(node as MeshInstance3D).material_override = mat

	for child in node.get_children():
		_apply_material_override_recursive(child, mat)


# ==============================================================================
# 4. OVERWORLD MOVEMENT & PURSUIT
# ==============================================================================
func _process(delta: float) -> void:
	if not _is_initialized or _is_in_active_combat or enemy_data == null or _is_moving:
		return

	var step_interval: float = maxf(0.5, enemy_data.movement_speed)
	_move_timer += delta

	if _move_timer >= step_interval:
		_move_timer = 0.0
		_check_pursuit_range()


func _check_pursuit_range() -> void:
	var player: Node3D = get_tree().get_first_node_in_group(&"player") as Node3D
	var player_cell: Vector2i = player.current_grid_pos if is_instance_valid(player) and ("current_grid_pos" in player) else Vector2i(-9999, -9999)

	var dist_to_player: int = absi(_grid_position.x - player_cell.x) + absi(_grid_position.y - player_cell.y)

	if dist_to_player <= 1:
		trigger_combat_encounter()
		return

	if not hasSpottedPlayer and _can_see_player(player_cell):
		hasSpottedPlayer = true

	if hasSpottedPlayer:
		_step_toward_target(player_cell)
	elif _grid_position != initial_cell:
		_step_toward_target(initial_cell)
	else:
		_step_patrol()


func _step_patrol() -> void:
	var step_dir: Vector2i = PATROL_OFFSETS[_patrol_index]
	var target_grid_pos: Vector2i = _grid_position + step_dir

	var map_mgr: Node3D = get_tree().current_scene.find_child("MapManager", true, false) as Node3D
	if is_instance_valid(map_mgr) and map_mgr.has_method("is_tile_blocked"):
		var grid_3d := Vector3i(target_grid_pos.x, 0, target_grid_pos.y)
		if map_mgr.is_tile_blocked(grid_3d):
			_patrol_index = randi() % PATROL_OFFSETS.size()
			_turn_to_facing(_vec_to_facing(PATROL_OFFSETS[_patrol_index]))
			return

	if randf() < 0.3:
		_patrol_index = randi() % PATROL_OFFSETS.size()

	_move_to_cell(target_grid_pos)


func _step_toward_target(target_cell: Vector2i) -> void:
	var is_blocked := func(cell: Vector2i) -> bool:
		return _is_cell_blocked(cell)

	var step_dir: Vector2i = _ai.get_smart_step(_grid_position, target_cell, is_blocked)
	
	if step_dir != Vector2i.ZERO:
		_move_to_cell(_grid_position + step_dir)
	else:
		var face_dir: Vector2i = _ai.get_step_vector(_grid_position, target_cell)
		if face_dir != Vector2i.ZERO:
			var new_facing: Facing = _vec_to_facing(face_dir)
			if new_facing != _current_facing:
				_current_facing = new_facing
				var target_rot_y: float = _facing_to_angle(_current_facing)
				
				var tween: Tween = create_tween()
				tween.tween_property(model_holder, "rotation_degrees:y", target_rot_y, 0.2) \
					.set_trans(Tween.TRANS_SINE) \
					.set_ease(Tween.EASE_OUT)


func _is_cell_blocked(cell: Vector2i) -> bool:
	var map_mgr: Node3D = get_tree().current_scene.find_child("MapManager", true, false) as Node3D
	if is_instance_valid(map_mgr) and map_mgr.has_method("is_tile_blocked"):
		return map_mgr.is_tile_blocked(Vector3i(cell.x, 0, cell.y))
	return false


func _move_to_cell(target_grid_pos: Vector2i) -> void:
	var move_vec: Vector2i = target_grid_pos - _grid_position
	_current_facing = _vec_to_facing(move_vec)

	var target_world_pos: Vector3 = _cell_to_world(target_grid_pos)
	var target_rot_y: float = _facing_to_angle(_current_facing)

	_is_moving = true
	_play_animation(&"walk", true)

	var tween: Tween = create_tween().set_parallel()
	tween.tween_property(self, "global_position", target_world_pos, 0.25) \
		.set_trans(Tween.TRANS_SINE) \
		.set_ease(Tween.EASE_IN_OUT)
	
	tween.tween_property(model_holder, "rotation_degrees:y", target_rot_y, 0.2) \
		.set_trans(Tween.TRANS_SINE) \
		.set_ease(Tween.EASE_OUT)

	tween.finished.connect(func() -> void:
		_grid_position = target_grid_pos
		_is_moving = false
		_play_animation(&"idle", true)
	, CONNECT_ONE_SHOT)


# ==============================================================================
# 6. DIRECTION & ROTATION HELPERS
# ==============================================================================
func _facing_to_angle(facing: Facing) -> float:
	match facing:
		Facing.NORTH: return 180.0
		Facing.EAST: return 90.0
		Facing.SOUTH: return 0.0
		Facing.WEST: return 270.0
	return 0.0


func _vec_to_facing(vec: Vector2i) -> Facing:
	if vec == Vector2i.ZERO:
		return _current_facing

	if abs(vec.x) > abs(vec.y):
		if vec.x > 0:
			return Facing.EAST
		else:
			return Facing.WEST
	else:
		if vec.y > 0:
			return Facing.SOUTH
		else:
			return Facing.NORTH


func _get_cardinal_string() -> String:
	match _current_facing:
		Facing.NORTH: return "NORTH"
		Facing.EAST: return "EAST"
		Facing.SOUTH: return "SOUTH"
		Facing.WEST: return "WEST"
	return "SOUTH"


# ==============================================================================
# 5. COMBAT TRIGGERING
# ==============================================================================
func _on_combat_started(enemy_payload: Variant, _party: Array, _enemy_facing: String) -> void:
	if not visible or _is_in_active_combat:
		return

	var is_target: bool = false

	if enemy_payload is Array:
		var payload_array: Array = enemy_payload as Array
		if payload_array == enemy_group:
			is_target = true
		else:
			for item in payload_array:
				if item == self or enemy_group.has(item) or (is_instance_valid(data) and item == data) or (is_instance_valid(enemy_data) and item == enemy_data):
					is_target = true
					break

	elif enemy_payload is Object and is_instance_valid(enemy_payload):
		if enemy_payload == self or enemy_group.has(enemy_payload) or (is_instance_valid(data) and enemy_payload == data) or (is_instance_valid(enemy_data) and enemy_payload == enemy_data):
			is_target = true

	if is_target:
		_is_in_active_combat = true
		hide()


# 2. Update _on_combat_ended to catch the player if they are overlapping after a fight
func _on_combat_ended(victory: bool) -> void:
	if not _is_in_active_combat:
		# If the player stepped into this enemy while another battle was ending, safely trigger it now
		if is_instance_valid(activation_area) and visible:
			for body in activation_area.get_overlapping_bodies():
				if body.is_in_group(&"player") or body.name == "Player" or body is CharacterBody3D or body.get_class() == "DungeonPlayer":
					call_deferred("trigger_combat_encounter")
					break
		return

	if victory:
		queue_free()
	else:
		_is_in_active_combat = false
		show()


func _connect_trigger_signals() -> void:
	if is_instance_valid(activation_area):
		if not activation_area.body_entered.is_connected(_on_body_entered):
			activation_area.body_entered.connect(_on_body_entered)

	var sb: Node = SignalBus
	if is_instance_valid(sb):
		if not sb.combat_started.is_connected(_on_combat_started):
			sb.combat_started.connect(_on_combat_started)
		if not sb.combat_ended.is_connected(_on_combat_ended):
			sb.combat_ended.connect(_on_combat_ended)


func _on_body_entered(body: Node) -> void:
	if body.is_in_group(&"player") or body.name == "Player" or body is CharacterBody3D or body is DungeonPlayer:
		trigger_combat_encounter()


func _get_ambush_component() -> GhostAmbushComponent:
	
	for child in get_children():
		if child is GhostAmbushComponent:
			GameLogger.combat("FOUND AMBUSH COMPONENT")
			return child as GhostAmbushComponent
	return null


# 1. Update the combat trigger to abort if combat is active or transitioning
func trigger_combat_encounter() -> void:
	if _is_in_active_combat:
		return
	if is_instance_valid(GameState) and GameState.has_method("can_begin_encounter") and not GameState.can_begin_encounter():
		return

	# 👻 GHOST AMBUSH GUARD: If this enemy is an ambush ghost, block direct combat unless the ambush failed
	var ambush_comp: GhostAmbushComponent = _get_ambush_component()
	GameLogger.combat("IS GHOST AMBUSH: %s" % [is_instance_valid(ambush_comp)])
	if is_instance_valid(ambush_comp) and not ambush_comp.can_trigger_combat():
		return

	_is_in_active_combat = true
	hide()

	if is_instance_valid(GameLogger):
		GameLogger.combat("Player engaged enemy pack (%d hostiles) at cell Vector2i%s! Triggering combat..." % [enemy_group.size(), _grid_position])

	var party_slots: Array = []
	if "current_party" in GameState and GameState.current_party != null:
		if "slots" in GameState.current_party:
			party_slots = GameState.current_party.slots

	SignalBus.combat_started.emit(enemy_group, party_slots, _get_cardinal_string())


func _is_player_adjacent() -> bool:
	var player: Node3D = get_tree().get_first_node_in_group(&"player") as Node3D
	if is_instance_valid(player) and ("current_grid_pos" in player):
		var p_cell: Vector2i = player.current_grid_pos
		var dist: int = absi(_grid_position.x - p_cell.x) + absi(_grid_position.y - p_cell.y)
		return dist <= 1
	return true


func _play_animation(action_key: StringName, loop: bool = true) -> void:
	if not is_instance_valid(model_holder):
		return

	var anim_player: AnimationPlayer = model_holder.find_child("AnimationPlayer", true, false) as AnimationPlayer
	if not is_instance_valid(anim_player):
		return

	var resolved_anim: StringName = _resolve_animation_name(anim_player, action_key)
	if resolved_anim.is_empty():
		return

	var anim: Animation = anim_player.get_animation(resolved_anim)
	if is_instance_valid(anim):
		anim.loop_mode = Animation.LOOP_LINEAR if loop else Animation.LOOP_NONE

	anim_player.play(resolved_anim)


func _resolve_animation_name(anim_player: AnimationPlayer, action_key: StringName) -> StringName:
	var candidates: Array = ANIM_MAPPINGS.get(action_key, [action_key])

	for candidate in candidates:
		var cand_name := StringName(str(candidate))
		if anim_player.has_animation(cand_name):
			return cand_name

	var available: PackedStringArray = anim_player.get_animation_list()
	for candidate in candidates:
		var cand_str: String = str(candidate).to_lower()
		for anim_name in available:
			if cand_str in anim_name.to_lower():
				return StringName(anim_name)

	return &""


func _can_see_player(player_cell: Vector2i) -> bool:
	var delta: Vector2i = player_cell - _grid_position
	var dist: int = absi(delta.x) + absi(delta.y)
	var vision_range: int = enemy_data.aggro_range_tiles if is_instance_valid(enemy_data) else 4

	if dist <= 0 or dist > vision_range:
		return false

	match _current_facing:
		Facing.NORTH:
			return delta.y < 0 and absi(delta.x) <= absi(delta.y)
		Facing.SOUTH:
			return delta.y > 0 and absi(delta.x) <= absi(delta.y)
		Facing.EAST:
			return delta.x > 0 and absi(delta.y) <= absi(delta.x)
		Facing.WEST:
			return delta.x < 0 and absi(delta.y) <= absi(delta.x)

	return false


func _turn_to_facing(new_facing: Facing) -> void:
	if new_facing != _current_facing:
		_current_facing = new_facing
		var target_rot_y: float = _facing_to_angle(_current_facing)
		var tween: Tween = create_tween()
		tween.tween_property(model_holder, "rotation_degrees:y", target_rot_y, 0.2) \
			.set_trans(Tween.TRANS_SINE) \
			.set_ease(Tween.EASE_OUT)
